#include "RA8889_MCU_IF.h"


/*********************************************************/
/*  SPI-4 ͨ��Э��                                         */
/*********************************************************/


/* SPIͨ����ʱ����ѡ����ɸ���MCU����Ƶ���� */
void SPI_Delay()
{
    unsigned int i = 1;
    while (--i != 0);
}

/* SPI-4 ��ʼ�� */
void SPI4_Init()
{
    SPI_MISO = 1;
    SPI_MOSI = 1;
    SPI_SCK  = 1;
    SPI_SS   = 1;
}

/* SPI-4 �������� */
void SPI4_SendByte(unsigned char dat)
{
    unsigned char t = 8;
    do {
        SPI_MOSI = (bit)(dat & 0x80);
        dat <<= 1;
        SPI_SCK = 0;
//        SPI_Delay();
        SPI_SCK = 1;
//        SPI_Delay();
    } while (--t != 0);

    SPI_SCK  = 1;
    SPI_MOSI = 0;
}

/* SPI-4 �������� */
unsigned char SPI4_ReceiveByte()
{
    unsigned char dat;
    unsigned char t = 8;
    SPI_MISO        = 1; // �ڶ�ȡ����֮ǰ��Ҫ�ѵ�Ƭ�����ߣ�ʹ֮�������״̬
    do {
        SPI_SCK = 0;
//        SPI_Delay();
        dat <<= 1;
        if (SPI_MISO) dat++;
        SPI_SCK = 1;
//        SPI_Delay();
    } while (--t != 0);
    return dat;
}

/* LCD API: д������ */
void LCD_CmdWrite(unsigned char cmd)
{
    SPI_SCK  = 1;
    SPI_MISO = 1;
    SPI_MOSI = 1;
    SPI_SS   = 0;
//    SPI_Delay();
    SPI4_SendByte(0x00);
    SPI4_SendByte(cmd);
//    SPI_Delay();
    SPI_SS = 1;
//    SPI_Delay();
}

/* LCD API: д������ */
void LCD_DataWrite(unsigned char Data)
{
    SPI_SCK  = 1;
    SPI_MISO = 1;
    SPI_MOSI = 1;
    SPI_SS   = 0;
    SPI4_SendByte(0x80);
    SPI4_SendByte(Data);
//    SPI_Delay();
    SPI_SS = 1;
//    SPI_Delay();
}

/* LCD API: ��ȡ���� */
unsigned char LCD_DataRead(void)
{
    unsigned char Data;

    SPI_SCK  = 1;
    SPI_MISO = 1;
    SPI_MOSI = 1;
    SPI_SS   = 0;
    SPI4_SendByte(0xc0);
    Data = SPI4_ReceiveByte();
//    SPI_Delay();
    SPI_SS = 1;

    return Data;
}

/* LCD API: ��ȡоƬ״̬ */
unsigned char LCD_StatusRead(void)
{
    unsigned char Data;

    SPI_SCK  = 1;
    SPI_MISO = 1;
    SPI_MOSI = 1;
    SPI_SS   = 0;
//    SPI_Delay();
    SPI4_SendByte(0x40);
    Data = SPI4_ReceiveByte();
//    SPI_Delay();
    SPI_SS = 1;

    return Data;
}

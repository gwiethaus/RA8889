#ifndef __DELAY_H
#define __DELAY_H

void delay_ms(unsigned int n);
void delay(unsigned short n);

#endif

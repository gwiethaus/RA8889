#include "Panel_RA8889_Reg.h"

//--------------------------------------------------------------------------------
// Set/Reset bits mask
//--------------------------------------------------------------------------------


//uso para Set bits (or apply)
#define cSetb0    0x01
#define cSetb1    0x02
#define cSetb2    0x04
#define cSetb3    0x08
#define cSetb4    0x10
#define cSetb5    0x20
#define cSetb6    0x40
#define cSetb7    0x80


//Uso para Clear bits (and apply)
#define cClrb0    0xfe
#define cClrb1    0xfd
#define cClrb2    0xfb
#define cClrb3    0xf7
#define cClrb4    0xef
#define cClrb5    0xdf
#define cClrb6    0xbf
#define cClrb7    0x7f


//--------------------------------------------------------------------------------
// RA8889 Frequency Configuration PLL
//--------------------------------------------------------------------------------

//Notes
//  1. Crystal resonator for RA8889, suggested 10MHz
//  2. SDRAM Access Clock, suggested 50~160MHz
//  3. RA8889 System Core Clock, suggested 50~130MHz
//  4. TFT Driving Clock PCLK, refer to LCD SPEC specified PCLK frequency requirements 
//  5. DRAM_FREQ >= CORE_FREQ   
//  6. CORE_FREQ >= (2 * SCAN_FREQ)

#define OSC_FREQ     10	                       // Crystal clock, unti: MHz
#define DRAM_FREQ    133                       // SDRAM clock frequency, unti: MHz		  
#define CORE_FREQ    120                       // Core (system) clock frequency, unit: MHz 
#define SCAN_FREQ    34                        // PSCK Panel Scan clock frequency, unit: MHz


//--------------------------------------------------------------------------------
// Panel LCD
//--------------------------------------------------------------------------------


//==== Valores tipicos do fabricante da tela de display LCD =====
//O RA8889 usa os valores adequados apra envio ao display LCD par a exibição correta das imagam
//Cada fabricante de tela possui as especificações e caracteristicas configuradas nesta constantes abaixo
//Consulte o Datasheet do fabricante de tela para entender estes valores 
//Exemplo de alguns Fabricnates
//https://www.twscreen.com/index.php/lcdpanel/search?brand=19&size=3

//===== LCD screen model =====
//#define ILI6122                                //ILITEK ILI6122 800x480 7.0" TFT-LCD, https://www.buydisplay.com/7-tft-lcd-touch-screen-display-module-800x480-for-mp4-gps-tablet-pc
//#define ST7277                                 //Sitronix ST7277 800x480 7.0" TFT-LCD, IPS, https://www.buydisplay.com/wide-angle-7-inch-800x480-color-ips-tft-display-st7277-controller
//#define HX8282                                 //HiMAX HX8282
//#define HX8264                                 //HiMAX HX8264 800x480 7.0"
//#define HX8664                                 //HiMAX HX8664 800x480 7.0"
//#define AWY_800480T70N02                       //AWY_800480T70N02
//#define LQ035NC111                             //Innolux LQ035NC111 320x240
//#define AWT_1024600L7N03                       //AWT_1024600L7N03
#define EK9713                                 //Fitipower EK9713 800x600/800x480, https://www.buydisplay.com/7-inch-lcd-screen-tft-display-module-wvga-800x480-at070tn90-at070tn92
//#define EK7330                                 //Fitipower EK7330 800x480 7.0" TFT
//#define EK73002                                //Fitipower EK73002
//#define L80480R70		                         //L80480R70 800x480
//#define AT070TN90                              //Innolux AT070TN90
//#define AT070TN92                              //Innolux AT070TN92 800X480 7"
//#define AT070TN94                              //Innolux AT070TN94
//#define AT070TN92_V1_TP                        //Innolux AT070TN92 V.1 TP 800X480 7.0" TFT-LCD 
//#define EJ080NA-04A                            //Innolux EJ080NA-04A 1024X768 8.0" TFT-LCD
//#define EJ080NA_04B                            //Innolux EJ080NA-04B 1024X768 8.0" TFT-LCD
//#define EJ080NA_04C                            //Innolux EJ080NA-04C 1024X768 8.0" TFT-LCD
//#define EJ080NA_05B                            //Innolux EJ080NA-05B 800x600 8.0" TFT-LCD
//#define NJ070NA-23A                            //Innolux NJ070NA-23A 1024X600 7" TFT-LCD
//#define ZJ070NA-01B                            //Innolux ZJ070NA-01B 1024x600
//#define AT070TN90                              //CMO AT070TN90 800x480 7.0" TFT-LCD 
//#define ET101000DM6                            //EDT ET101000DM6 1024x600 
//#define B116XW03_V0                            //AUO B116XW03 V0 1366x768
//#define G190SVT01                              //AUO G190SVT01 1680x342 
//#define G070VW01_V1                            //AUO G070VW01 V1 800X480 7" TFT-LCD 
//#define G070VW01_V0                            //AUO G070VW01 V0 800X480 7" TFT-LCD 
//#define LQ150X1LGN2C                           //SHARP LQ150X1LGN2C
//#define LQ190E1LW52                            //SHARP LQ190E1LW52 1280x1024 
//#define LQ121S1LG81                            //SHARP LQ121S1LG81
//#define LQ156M1LG21                            //SHARP LQ156M1LG21 1920x1080
//#define LQ201U1LW32                            //SHARP LQ201U1LW32 1600x1200
//#define LQ150X1LGN2C_LVDS1                     //SHARP LQ150X1LGN2C_LVDS1 1024x768
//#define LQ150X1LGN2C_LVDS2                     //SHARP LQ150X1LGN2C_LVDS2 1024x768

//Valores foi fornecido pela BuyDisplay
#ifdef EK9713                                  //Fitipower EK9713 800x600/800x480
  #define LCD_HW           800                 //Horizontal Width
  #define LCD_VH           480                 //Vertical Height
  #define LCD_HBPD         20                  //HS Back Porch (Blanking)
  #define LCD_HFPD         160                 //HS Front Porch
  #define LCD_HSPW         5                   //HS Pulse Width
  #define LCD_VBPD         20                  //VS Back Porch (Blanking)
  #define LCD_VFPD         12                  //VS Front Porch
  #define LCD_VSPW         3                   //VS Pulse Width
#endif

#ifdef EJ080NA_05B                             //Innolux EJ080NA-05B 800x600 8.0" TFT-LCD
  #define LCD_HW           800                 //Horizontal Width
  #define LCD_VH           600                 //Vertical Height
  #define LCD_HBPD         38                  //HS Back Porch (Blanking) - 46
  #define LCD_HFPD         210                 //HS Front Porch - 16~354
  #define LCD_HSPW         8                   //HS Pulse Width - 1~40C
  #define LCD_VBPD         15                  //VS Back Porch (Blanking) - 23
  #define LCD_VFPD         12                  //VS Front Porch - 1~77
  #define LCD_VSPW         8                   //VS Pulse Width - 1~20C
#endif

#ifdef AT070TN92                               //Innolux AT070TN92 800X480 7"  TFT-LCD
  #define LCD_HW           800                 //Horizontal Width
  #define LCD_VH           480                 //Vertical Height
  #define LCD_HBPD         30                  //HS Back Porch (Blanking) - 46
  #define LCD_HFPD         210                 //HS Front Porch - 16~354
  #define LCD_HSPW         16                  //HS Pulse Width - 1~40C
  #define LCD_VBPD         13                  //VS Back Porch (Blanking) - 23
  #define LCD_VFPD         22                  //VS Front Porch - 7~147
  #define LCD_VSPW         10                  //VS Pulse Width - 1~20
#endif


//--------------------------------------------------------------------------------
// Page(image buffer) configure
//--------------------------------------------------------------------------------


/*The maximum number of pages is based on SDRAM capacity and color depth and width and height of one page*/
/*For example we used 128Mbit SDRAM that capacity =  16Mbyte */
/*The SDRAM is divided into several image buffers and the maximum number of image buffers is limited by the 
memory size. For example : page_size = 800*600*2byte(16bpp) = 960000byte, maximum number = 16/0.96 = 16.6 */
/*vertical mulit page application*/
#define MAX_LAYER 10     //numero maxim o de layer para endereçar
#define MEMORY_SIZE 128 * 1024 *1024  //Tamanho da memoria em bits (128Mb convertidos em bits)

//se tornar obsoleto (Não utilziar)
//Calculo é feito por LayerStartAddr()
#define LAYER1_START_ADDR  800*480*2*0
#define LAYER2_START_ADDR  800*480*2*1
#define LAYER3_START_ADDR  800*480*2*2
#define LAYER4_START_ADDR  800*480*2*3
#define LAYER5_START_ADDR  800*480*2*4
#define LAYER6_START_ADDR  800*480*2*5
#define LAYER7_START_ADDR  800*480*2*6
#define LAYER8_START_ADDR  800*480*2*7
#define LAYER9_START_ADDR  800*480*2*8
#define LAYER10_START_ADDR 800*480*2*9


//--------------------------------------------------------------------------------
// Select SPI / I2C / Parallel
//--------------------------------------------------------------------------------


//Padrão de comunicacao do MCU com o RA8889
//  #define SPI3
    #define SPI4
//  #define I2C
//  #define PARALLEL

#ifdef SPI3
  #define SPI
#endif

#ifdef SPI4
  #define SPI
#endif

/*====  Master I2C filter Enabled/Disable =====*/
    #define Enable_I2CM_Noise_Filter
//  #define Disable_I2CM_Noise_Filter

//Select velocidade de clock máximo da comuncaicao SPI
    #define SPI_CLOCK_SPEED_MAX  8000000       //Para Arduino Uno/Mega
//#define SPI_CLOCK_SPEED_MAX  20000000        //Para ESP32


//--------------------------------------------------------------------------------
// System
//--------------------------------------------------------------------------------


//Ativa funcao de existencia do RA8889
#define CHECK_RA8889


//--------------------------------------------------------------------------------
// Color depth
//--------------------------------------------------------------------------------


#define COLOR_DEPH_8BPP   8
#define COLOR_DEPH_16BPP  16
#define COLOR_DEPH_24BPP  24


//--------------------------------------------------------------------------------
// Select Wait FIFO apra evitar que ocorra transbordamento. Isso acotence para 
// MCU muito lentas. Ative esta funcao caso houver corrompimento de pixels na tela
// imagens distorcidas e pixels estranhos
//--------------------------------------------------------------------------------

//#define USE_XNWAIT

//--------------------------------------------------------------------------------
// Select MCU and Color Depth
//--------------------------------------------------------------------------------

//	#define MCU_8bit_COLORDEPTH_8bpp			  
//	#define MCU_8bit_COLORDEPTH_16bpp	
//	#define MCU_8bit_COLORDEPTH_24bpp
	#define MCU_16bit_COLORDEPTH_16bpp		
//  #define MCU_16bit_COLORDEPTH_24bpp_Mode1
//	#define MCU_16bit_COLORDEPTH_24bpp_Mode2

//Descomente esta linha para selecionar escala convertida para tom de cinza 
//#define USE_GRAYSCALE

#ifdef MCU_8bit_COLORDEPTH_8bpp
  #define MCU8
  #define COLOR_DEPTH_8
#endif

#ifdef MCU_8bit_COLORDEPTH_16bpp
  #define MCU8
  #define COLOR_DEPTH_16
#endif

#ifdef MCU_8bit_COLORDEPTH_24bpp
  #define MCU8
  #define COLOR_DEPTH_24
#endif

#ifdef MCU_16bit_COLORDEPTH_16bpp
  #define MCU16
  #define COLOR_DEPTH_16
#endif

#ifdef MCU_16bit_COLORDEPTH_24bpp_Mode1
  #define MCU16
  #define COLOR_DEPTH_24
#endif

#ifdef MCU_16bit_COLORDEPTH_24bpp_Mode2
  #define MCU16
  #define COLOR_DEPTH_24
#endif


//--------------------------------------------------------------------------------
//
// Macro RGB(r,g,b) 
// Adaptável para cores e escala de cinza de acordo com o Color Depth escolhido 
// 8, 16 ou 25bpp
//
//--------------------------------------------------------------------------------


#ifdef COLOR_DEPH_8
  #if USE_GRAYSCALE
    #define RGB(r,g,b) ( \
      ((((r)*30 + (g)*59 + (b)*11)/100 & 0xE0))        | \
      ((((r)*30 + (g)*59 + (b)*11)/100 & 0xE0) >> 3)   | \
      ((((r)*30 + (g)*59 + (b)*11)/100 & 0xC0) >> 6) )
  #else
    #define RGB(r,g,b) ( ((r & 0xE0)) | ((g & 0xE0)>>3) | ((b & 0xC0)>>6) )
  #endif
#endif

#ifdef COLOR_DEPH_16
  #if USE_GRAYSCALE
    #define RGB(r,g,b) ( \
      (((((r)*30 + (g)*59 + (b)*11)/100) & 0xF8) << 8) | \
      (((((r)*30 + (g)*59 + (b)*11)/100) & 0xFC) << 3) | \
      (((((r)*30 + (g)*59 + (b)*11)/100) & 0xF8) >> 3) )
  #else
    #define RGB(r,g,b) ( ((r & 0xF8)<<8) | ((g & 0xFC)<<3) | ((b & 0xF8)>>3) )
  #endif
#endif

#ifdef COLOR_DEPH_24
  #if USE_GRAYSCALE
    #define RGB(r,g,b) ( \
      (((((r)*30 + (g)*59 + (b)*11)/100) << 16) | \
       ((((r)*30 + (g)*59 + (b)*11)/100) << 8)  | \
       (((r)*30 + (g)*59 + (b)*11)/100)) )
  #else
    #define RGB(r,g,b) ( ((r & 0xFF)<<16) | ((g & 0xFF)<<8) | (b & 0xFF) )
  #endif
#endif


//--------------------------------------------------------------------------------
//
// Color
//
//--------------------------------------------------------------------------------


// --- Básicas ---
#define  clBlack                RGB(0,0,0)
#define  clWhite                RGB(255,255,255)
#define  clRed                  RGB(255,0,0)
#define  clLime                 RGB(0,255,0)
#define  clBlue                 RGB(0,0,255)
#define  clYellow               RGB(255,255,0)
#define  clCyan                 RGB(0,255,255)
#define  clMagenta              RGB(255,0,255)
#define  clSilver               RGB(192,192,192)
#define  clGray                 RGB(128,128,128)
#define  clMaroon               RGB(128,0,0)
#define  clOlive                RGB(128,128,0)
#define  clGreen                RGB(0,128,0)
#define  clPurple               RGB(128,0,128)
#define  clTeal                 RGB(0,128,128)
#define  clNavy                 RGB(0,0,128)

// --- Outras cores ---
#define  clSnow                 RGB(255,250,250)
#define  clWhiteSmoke           RGB(245,245,245)
#define  clAntiqueWhite         RGB(250,235,215)
#define  clDarkCyan             RGB(0,139,139)
#define  clDarkGoldenrod        RGB(184,134,11)
#define  clDarkSalmon           RGB(233,150,122)
#define  clDarkSlateGray        RGB(47,79,79)
#define  clGhostWhite           RGB(248,248,255)
#define  clGoldenrod            RGB(218,165,32)
#define  clHoneydew             RGB(240,255,240)
#define  clIndianRed            RGB(205,92,92)
#define  clIvory                RGB(255,255,240)
#define  clLemonChiffon         RGB(255,250,205)
#define  clLightSalmon          RGB(255,160,122)
#define  clLightSlateGray       RGB(119,136,153)
#define  clLinen                RGB(250,240,230)
#define  clMistyRose            RGB(255,228,225)
#define  clOldLace              RGB(253,245,230)
#define  clOliveDrab            RGB(107,142,35)
#define  clPaleGoldenrod        RGB(238,232,170)
#define  clPeru                 RGB(205,133,63)
#define  clRosyBrown            RGB(188,143,143)
#define  clSaddleBrown          RGB(139,69,19)
#define  clSalmon               RGB(250,128,114)
#define  clSandyBrown           RGB(244,164,96)
#define  clSienna               RGB(160,82,45)
#define  clSlateGray            RGB(112,128,144)

// --- Vermelhos / Rosas ---
#define  clPink                 RGB(255,192,203)
#define  clLightPink            RGB(255,182,193)
#define  clHotPink              RGB(255,105,180)
#define  clDeepPink             RGB(255,20,147)
#define  clMediumVioletRed      RGB(199,21,133)
#define  clPaleVioletRed        RGB(219,112,147)
#define  clCrimson              RGB(220,20,60)
#define  clFireBrick            RGB(178,34,34)
#define  clDarkRed              RGB(139,0,0)
#define  clOrangeRed            RGB(255,69,0)
#define  clTomato               RGB(255,99,71)
#define  clLightCoral           RGB(240,128,128)
#define  clCoral                RGB(255,127,80)
#define  clOrange               RGB(255,165,0)
#define  clDarkOrange           RGB(255,140,0)
#define  clGold                 RGB(255,215,0)
#define  clLightGoldenrodYellow RGB(250,250,210)

// --- Amarelos / Marrons ---
#define  clLightYellow          RGB(255,255,224)
#define  clYellowGreen          RGB(154,205,50)
#define  clDarkKhaki            RGB(189,183,107)
#define  clKhaki                RGB(240,230,140)
#define  clPeachPuff            RGB(255,218,185)
#define  clPapayaWhip           RGB(255,239,213)
#define  clMoccasin             RGB(255,228,181)
#define  clNavajoWhite          RGB(255,222,173)
#define  clBurlyWood            RGB(222,184,135)
#define  clTan                  RGB(210,180,140)
#define  clWheat                RGB(245,222,179)
#define  clBisque               RGB(255,228,196)
#define  clBlanchedAlmond       RGB(255,235,205)
#define  clCornsilk             RGB(255,248,220)

// --- Verdes ---
#define  clLawnGreen            RGB(124,252,0)
#define  clChartreuse           RGB(127,255,0)
#define  clGreenYellow          RGB(173,255,47)
#define  clSpringGreen          RGB(0,255,127)
#define  clMediumSpringGreen    RGB(0,250,154)
#define  clLightGreen           RGB(144,238,144)
#define  clLightSeaGreen        RGB(32,178,170)
#define  clMintGreen            RGB(152,255,152)  
#define  clPaleGreen            RGB(152,251,152)
#define  clDarkSeaGreen         RGB(143,188,143)
#define  clMediumSeaGreen       RGB(60,179,113)
#define  clSeaGreen             RGB(46,139,87)
#define  clForestGreen          RGB(34,139,34)
#define  clDarkGreen            RGB(0,100,0)
#define  clDarkOliveGreen       RGB(85,107,47)
#define  clLimeGreen            RGB(50,205,50)

// --- Light / Pastel / UI ---
#define  clAliceBlue            RGB(240,248,255)
#define  clLavender             RGB(230,230,250)
#define  clLavenderBlush        RGB(255,240,245)
#define  clGhostWhite           RGB(248,248,255)
#define  clMintCream            RGB(245,255,250)
#define  clSeashell             RGB(255,245,238)
#define  clFloralWhite          RGB(255,250,240)
#define  clOldLace              RGB(253,245,230)
#define  clIvory                RGB(255,255,240)
#define  clLightCyan            RGB(224,255,255)
#define  clAzure                RGB(240,255,255)
#define  clHoneydew             RGB(240,255,240)
#define  clLinen                RGB(250,240,230)
#define  clBeige                RGB(245,245,220)
#define  clLightGoldenrod       RGB(238,221,130)
#define  clSnowWhite            RGB(250,250,250)
#define  clIvoryWhite           RGB(255,255,240)

// --- Pastéis / Light Colors ---
#define  clPeach                RGB(255,218,185)
#define  clPastelPink           RGB(255,192,203)
#define  clPastelBlue           RGB(173,216,230)
#define  clPastelGreen          RGB(152,251,152)
#define  clMint                 RGB(189,252,201)
#define  clApricot              RGB(255,229,180)

// --- Azuis ---
#define  clAqua                 RGB(0,255,255)
#define  clCyan                 RGB(0,255,255)
#define  clPaleTurquoise        RGB(175,238,238)
#define  clAquamarine           RGB(127,255,212)
#define  clMediumAquamarine     RGB(102,205,170)
#define  clTurquoise            RGB(64,224,208)
#define  clMediumTurquoise      RGB(72,209,204)
#define  clDarkTurquoise        RGB(0,206,209)
#define  clCadetBlue            RGB(95,158,160)
#define  clSteelBlue            RGB(70,130,180)
#define  clLightSteelBlue       RGB(176,196,222)
#define  clPowderBlue           RGB(176,224,230)
#define  clLightBlue            RGB(173,216,230)
#define  clSkyBlue              RGB(135,206,235)
#define  clLightSkyBlue         RGB(135,206,250)
#define  clDeepSkyBlue          RGB(0,191,255)
#define  clDodgerBlue           RGB(30,144,255)
#define  clCornflowerBlue       RGB(100,149,237)
#define  clMediumSlateBlue      RGB(123,104,238)
#define  clMidnightBlue         RGB(25,25,112)
#define  clRoyalBlue            RGB(65,105,225)
#define  clBlueViolet           RGB(138,43,226)
#define  clIndigo               RGB(75,0,130)
#define  clDarkSlateBlue        RGB(72,61,139)
#define  clMediumBlue           RGB(0,0,205)
#define  clDarkBlue             RGB(0,0,139)
#define  clNavy                 RGB(0,0,128)

// --- Roxos / Violetas ---
#define  clThistle              RGB(216,191,216)
#define  clPlum                 RGB(221,160,221)
#define  clViolet               RGB(238,130,238)
#define  clOrchid               RGB(218,112,214)
#define  clFuchsia              RGB(255,0,255)
#define  clMediumOrchid         RGB(186,85,211)
#define  clDarkOrchid           RGB(153,50,204)
#define  clDarkViolet           RGB(148,0,211)
#define  clDarkMagenta          RGB(139,0,139)
#define  clMediumPurple         RGB(147,112,219)
#define  clSlateBlue            RGB(106,90,205)
#define  clLavenderPurple       RGB(180,167,214)
#define  clAmethyst             RGB(153,102,204)

// --- Neutros / Dark Colors (Dark Theme) ---
#define  clCharcoal             RGB(54,69,79)
#define  clGunmetal             RGB(42,52,57)
#define  clSlate                RGB(112,128,144)
#define  clSlateGrayDark        RGB(40,40,40)
#define  clCoolGray             RGB(140,146,172)
#define  clGraphite             RGB(58,58,60)

// --- Neutros / Escala de cinza ---
#define  clGainsboro            RGB(220,220,220)
#define  clLightGray            RGB(211,211,211)
#define  clSilverGray           RGB(192,192,192)
#define  clDarkGray             RGB(169,169,169)
#define  clDimGray              RGB(105,105,105)
#define  clGray25               RGB(64,64,64)
#define  clGray50               RGB(128,128,128)
#define  clGray75               RGB(192,192,192)

#ifdef GRAY_SCALE
	#define color65k_grayscale1    2113
    #define color65k_grayscale2    2113*2
    #define color65k_grayscale3    2113*3
    #define color65k_grayscale4    2113*4
    #define color65k_grayscale5    2113*5
    #define color65k_grayscale6    2113*6
    #define color65k_grayscale7    2113*7
    #define color65k_grayscale8    2113*8
    #define color65k_grayscale9    2113*9
    #define color65k_grayscale10   2113*10
    #define color65k_grayscale11   2113*11
    #define color65k_grayscale12   2113*12
    #define color65k_grayscale13   2113*13
    #define color65k_grayscale14   2113*14
    #define color65k_grayscale15   2113*15
    #define color65k_grayscale16   2113*16
    #define color65k_grayscale17   2113*17
    #define color65k_grayscale18   2113*18
    #define color65k_grayscale19   2113*19
    #define color65k_grayscale20   2113*20
    #define color65k_grayscale21   2113*21
    #define color65k_grayscale22   2113*22
    #define color65k_grayscale23   2113*23
    #define color65k_grayscale24   2113*24
    #define color65k_grayscale25   2113*25
    #define color65k_grayscale26   2113*26
    #define color65k_grayscale27   2113*27
    #define color65k_grayscale28   2113*28
    #define color65k_grayscale29   2113*29
    #define color65k_grayscale30   2113*30
#endif

//--------------------------------------------------------------------------------
// Class enum
//--------------------------------------------------------------------------------

//#pragma message "DEBUG: entrando em PageReg"

//Troca de pagina de registrador

enum class ePageReg : uint8_t {
  Page0 = 0x00,                                /* Page 0 Register Set */
  Page1 = cSetb0                               /* Page 1 Register Set */
};


//Tipo de seleção de destino da porta de memória do RA8889
enum class MemoryPortDest : uint8_t {
  SDRAM            = 0x0,
  GammaTable       = cSetb0,
  GraphicCursorRAM = cSetb1,
  ColorPaletteRAM  = cSetb0 | cSetb1
};


//Interface de saída do TFT com o RA8889
enum class TFTInterface : uint8_t {            
  IF_24BIT = 0x0,                              /* Saída TFT 24-bits */
  IF_18BIT = cSetb3,                           /* Saída TFT 18-bits */
  IF_16BIT = cSetb4,                           /* Saída TFT 16-bits */
  IF_NONE  = cSetb4 | cSetb3                   /* Sem Saída TFT */
};


//Host Read/Write Memory Direction
enum class MemoryDirection : uint8_t {
  LeftRight_TopBotom  = 0b00,
  RightLeft_TopBotom  = 0b01,
  TopBottom_LeftRight = 0b10,        
  BottomTop_LeftRight = 0b11
};


//Horizontal Scan Direction
enum class HSCANDir : uint8_t {                //bit 4
  LeftToRight        = 0x0,                    
  RightToLeft        = cSetb4                  
};


//Vertical Scan Direction
enum class VSCANDir : uint8_t {                //bit 3
  TopToBottom        = 0x0,                    
  BottomToTop        = cSetb3                  
};


//Parallel XDATA[23~0] Color Format
enum class PDATAColorFmt : uint8_t {          //bit [2~0]
  RGB               = 0x0,
  RBG               = 0x1,
  GRB               = 0x2,
  GBR               = 0x3,
  BRG               = 0x4,
  BGR               = 0x5,
  Gray              = 0x6,
  BW                = 0x7
};


//Panel Scan Clock PCLK Edge Type
enum class PCLKEdge : uint8_t {                //bit [7]
  Rising            = 0x0,                     //Borda de subida
  Falling           = cSetb7                   //Borda de descida
};


enum class HSYNCPolarity : uint8_t {           //bit [6]
  Low              = 0x0,
  High             = cSetb7
};


enum class VSYNCPolarity : uint8_t {           //bit [6]
  Low              = 0x0,
  High             = cSetb6
};


enum class DEPolarity : uint8_t {              //bit [5]
  High             = 0x0,
  Low              = cSetb5
};


enum class PIPSelect : uint8_t {              //bit [4]
  PIP1            = 0x00,                     //Picture-to-Picute (PIP 1) 
  PIP2            = cSetb4                    //Picture-to-Picute (PIP 2)
};


//Supported Panel Resolution (Horiz x Vert)
//Note:  The actual panel resolution depends on the pixel clock and color depth.
//When RA8889 TFT Output supports 24bpp 
//CCLK Max. = 120MHz 
//SCLK Max. = 60MHz 
//Required LCD clock ≒ LCD vertical Pixel * LCD horizontal Pixel * 60(Hz) * 1.1 
//If Required LCD Clock > SCLK, the LCD refresh rate (Refresh Rate or VSYNC rate) will be lower than 
//60Hz under this application condition.
enum class ePanelResolution : uint8_t {
  r320x240,                       //QVGA:  320 x 240 x 16/18/24-bit LCD panel 
  r480x272,                       //WQVGA: 480 x 272 x 16/18/24-bit LCD panel
  r640x480,                       //VGA:   640 x 480 x 16/18/24-bit LCD panel 
  r800x480,                       //WVGA:  800 x 480 x 16/18/24-bit LCD panel   
  r800x600,                       //SVGA:  800 x 600 x 16/18/24-bit LCD panel
  r960x540,                       //QHD:   960 x 540 x 16/18/24-bit LCD panel
  r1024x600,                      //WSVGA: 1024 x 600 x 16/18/24-bit LCD panel
  r1024x768,                      //XGA:   1024 x 768 x 16/18/24-bit LCD panel 
  r1280x768,                      //WXGA:  1280 x 768 x 16/18/24-bit LCD panel
  r1280x800,                      //WXGA:  1280 x 800 x 16/18/24-bit LCD panel 
  r1366x768                       //WXGA:  1366 x 768 x 16/18/24-bit LCD panel
};


//minha nova impelemtnacao, colocar isso de forma ajustada no sistema apra selecao do COLOR DEPTH 8/16/24 bpp
enum class eColorDepthBPP : uint8_t {
  bpp8  = COLOR_DEPH_8BPP,                     //Color Depth 8bpp
  bpp16 = COLOR_DEPH_16BPP,                    //Color Depth 16bpp
  bpp24 = COLOR_DEPH_24BPP                     //Color Depth 24bpp
};


enum class FontSource : uint8_t {
  InternalCGROM =  0x00,                        //0b00 Select internal CGROM Character.
  ExternalCGROM =  cSetb6,                      //0b01 Select external CGROM Character. (Genitop serial flash) 
  UserDefined   =  cSetb7                       //0b10 Select user-defined Character.
};


// Enum para os padrões ISO/IEC 8859 suportados pela CGROM interna
enum class InternalCGROM_ISO8859 : uint8_t {
 ISO8859_1 = 0x0,                              // 0b00: Character ISO/IEC 8859-1
 ISO8859_2 = cSetb0,                           // 0b01: Character ISO/IEC 8859-2.
 ISO8859_4 = cSetb1,                           // 0b10: Character ISO/IEC 8859-4.
 ISO8859_5 = cSetb1 | cSetb0                   // 0b11: Character ISO/IEC 8859-5.
};


// Enum para alturas de fonte suportadas
enum class FontHeight : uint8_t
{
  H16 = 16,                                    // 8x16 / 16x16
  H24 = 24,                                    // 12x24 / 24x24
  H32 = 32                                     // 16x32 / 32x32
};


// Enum Font Horizontal/Vertical Enlagement Factors
enum class FontEnlargFactor : uint8_t
{
  X1 = 0,                           //factor 1x
  X2 = 1,                           //factor 2x
  X3 = 2,                           //factor 3x
  X4 = 3                            //factor 4x
};


enum class InterruptLevel : uint8_t {
  Low  = 0x0,                      //Reset bit 7
  High = cSetb7                    //Set bit 7
};


enum class eInterrupLevelTrigger : uint8_t {
  Low      = 0b00,                              //low level trigger    
  Falling  = 0b01,                              //falling edge trigger
  High     = 0b10,                              //high level trigger
  rising   = 0b11                              //rising edge trigger
};


enum class eNSS_Channel : uint8_t {
  XNSFCS0 = 0,                   
  XNSFCS1 = 1,                 
  XNSFCS2 = 2,               
  XNSFCS3 = 3                
};


enum class eDividerClock : uint8_t {
  X1 = 0b00,                                   //divided by 1, 1/1 
  X2 = 0b01,                                   //divided by 2, 1/2  
  X4 = 0b10,                                   //divided by 4, 1/4
  X8 = 0b11                                    //divided by 8, 1/8
};


//Uso com BTE Operation Code
enum class eBTEOpCode : uint8_t {
  MPU_WROP            = 0b0000,      //MPU Write BTE with ROP.
  MPU_RNOP            = 0b0001,      //MPU Read BTE without ROP.
  MEM_COPY_POS_ROP    = 0b0010,      //Memory copy (move) BTE in positive direction with ROP.
  MEM_COPY_NEG_ROP    = 0b0011,      //Memory copy (move) BTE in negative direction with ROP.
  MPU_TWRITE          = 0b0100,      //MPU Transparent Write BTE. (w/o ROP.)
  MPU_T_COPY_POS      = 0b0101,      //Transparent Memory copy (move) BTE in positive direction (w/o ROP.)
  PAT_ROP             = 0b0110,      //Pattern Fill with ROP.
  PAT_CHROMA          = 0b0111,      //Pattern Fill with key-chroma
  COLOR_EXP           = 0b1000,      //Color Expansion
  COLOR_EXP_T         = 0b1001,      //Color Expansion with transparency
  MOVE_POS_ALPHA      = 0b1010,      //Move BTE in positive direction with Alpha blending
  MPU_WALPHA          = 0b1011,      //MPU Write BTE with Alpha blending
  SOLID_FILL          = 0b1100       //Solid Fill
};


/**
 * @brief BTE ROP (Raster Operation) Codes for RA8889
 *
 * These codes define how the source(s) (S0, S1) are combined to produce
 * the destination (D). They are used with BTE operations that support ROP.
 */
enum class eROPCode : uint8_t {
    Blackness       = 0b0000,  // 0
    NotS0_And_NotS1 = 0b0001,  // ~S0・~S1  or  ~(S0 + S1)
    NotS0_And_S1    = 0b0010,  // ~S0・S1
    NotS0           = 0b0011,  // ~S0
    S0_And_NotS1    = 0b0100,  // S0・~S1
    NotS1           = 0b0101,  // ~S1
    S0_Xor_S1       = 0b0110,  // S0 ^ S1
    NotS0_Or_NotS1  = 0b0111,  // ~S0 + ~S1  or  ~(S0・S1)
    S0_And_S1       = 0b1000,  // S0・S1
    Not_S0_Xor_S1   = 0b1001,  // ~(S0 ^ S1)
    S1              = 0b1010,  // S1
    NotS0_Or_S1     = 0b1011,  // ~S0 + S1
    S0              = 0b1100,  // S0
    S0_Or_NotS1     = 0b1101,  // S0 + ~S1
    S0_Or_S1        = 0b1110,  // S0 + S1
    Whiteness       = 0b1111   // 1
};


class Panel_RA8889 {
	
	public:
		Panel_RA8889(uint8_t cs, uint8_t rst);
		bool Begin(void);
		void DisplayOn(bool on);
		void GraphicMode(void);     //overload
		bool IsGraphicMode(void);     //overload
		void TextMode(void);
		uint16_t Width(void);
        uint16_t Height(void);
		
        uint32_t LayerStartAddr(uint8_t layer);
		void MainImage_StartAddress(uint32_t addr);
		void MainImage_Width(uint16_t Wx);
		void MainWindow_StartXY(uint16_t wx, uint16_t hy);
		void CanvasImage_StartAddr(uint32_t addr);
		void CanvasImage_Width(uint16_t Wx);
		void ActiveWindow_XY(uint16_t Wx, uint16_t hHy);
		void ActiveWindow_WidhtHeight(uint16_t Wx, uint16_t Hy); 
		
		void ForegroundColorRGB(uint8_t red, uint8_t green, uint8_t blue);
		void ForegroundColor8bpp(uint8_t color);
		void ForegroundColor16bpp(uint16_t color);
		void ForegroundColor24bpp(uint32_t color);
		void BackgroundColorRGB(uint8_t red, uint8_t green, uint8_t blue);
		void BackgroundColor8bpp(uint8_t color);
		void BackgroundColor16bpp(uint16_t color);
		void BackgroundColor24bpp(uint32_t color);
		
		void putPixel(uint16_t x, uint16_t y, uint32_t color);
		void DrawPixel(uint16_t x, uint16_t y, uint32_t color);
		void DrawLine(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, uint32_t color);
		void DrawSquare (uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, uint32_t forecolor, bool bfill = false);
		void DrawTriangle(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, uint16_t x3, uint16_t y3, uint32_t forecolor, bool bfill = false);
        void DrawCircle (uint16_t x1, uint16_t y1, uint16_t R, uint32_t forecolor, bool bfill = false);
		void DrawEllipse (uint16_t x1, uint16_t y1, uint16_t Rx, uint16_t Ry, uint32_t forecolor, bool bfill = false);
        void DrawCurveLeftUp(uint16_t x1, uint16_t y1, uint16_t Rx, uint16_t Ry, uint32_t forecolor, bool bfill = false);
        void DrawCurveRightDown(uint16_t x1, uint16_t y1, uint16_t Rx, uint16_t Ry, uint32_t forecolor, bool bfill = false);
        void DrawCurveRightUp(uint16_t x1, uint16_t y1, uint16_t Rx, uint16_t Ry, uint32_t forecolor, bool bfill = false);
		void DrawCurveLeftDown(uint16_t x1, uint16_t y1, uint16_t Rx, uint16_t Ry, uint32_t forecolor, bool bfill = false);
		void DrawCircleSquare(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, uint16_t Rx, uint16_t Ry, uint32_t forecolor, bool bfill = false);
		
		void DrawPicture(uint16_t Wx, uint16_t Hy, uint16_t width, uint16_t height, const uint8_t *datap);
		void ShowText(char *str);
		
//Metodos PROTEGIDOS

		uint8_t StatusRead(void);
    void RegisterWrite(uint8_t Cmd, uint8_t Data);
    uint8_t RegisterRead(uint8_t Cmd);
		void HardwareReset(void);
    void CoreTask_WaitReady(void);
		void Draw_WaitReady(void);
		bool IC_WaitReady(void);
		bool Panel_RA8889::Initialize(void);
		void Wait_WriteFIFO_NotFull(void);
		void Wait_WriteFIFO_Empty(void);
		void Wait_ReadFIFO_NotFull(void);
		void Wait_ReadFIFO_NotEmpty(void);
		void GotoLinearAddr(uint32_t addr);
		void GotoPixel_Linear(uint32_t addr);
		void GotoPixel_XY(uint16_t Wx, uint16_t Hy);
		void GotoText_XY(uint16_t Wx, uint16_t Hy);
		void ShowPicture(uint32_t size, const uint8_t *datap);
		
		void DMA_24bit_Block (uint8_t SCS, uint8_t Clk, uint16_t X1, uint16_t Y1, uint16_t X_W, uint16_t Y_H, uint16_t P_W, uint32_t Addr);

		void PanelResolution(ePanelResolution resolution);
		void PageSwitch(ePageReg pr);
		
		void SPISetCS(uint8_t level_cs);
		uint8_t SPIRwByte(uint8_t value);
		void SPI_CmdWrite(uint8_t cmd);
	  void SPI_DataWrite(uint8_t data);
		void SPI_DataWrite16bpp(uint16_t data);
		void SPI_DataWrite24bpp(uint32_t data);
		void SPI_DataWrite_Pixel(uint16_t data);
		uint8_t SPI_DataRead(void);
    void SPI_Init(void);
		
		void PLL_WaitReady(void);
		bool PLL_ConfigClocks(int8_t scanclk, int8_t dramclk, int8_t coreclk, int8_t xtalclk);
		bool SDRAM_WaitReady(void);
		void SDRAM_Init(void);
		
		void MemorySelect_SDRAM(void);
		void MemorySelect_GammaTable(void);
		void MemorySelect_GraphicCursorRAM(void);
		void MemorySelect_ColorPaletteRAM(void);
		void MemoryPort_Select(MemoryPortDest dest);
		
		void Interrupt_Resume_Enable(bool b);
		void ExtInterrupt_Input_Enable(bool b);
		void Interrupt_I2CM_Enable(bool b);
		void Interrupt_VSync_Enable(bool b);
		void Interrupt_KeyScan_Enable(bool b);
		void Interrupt_ClearMultiEventTask_Enable(bool b);
		void Interrupt_PWM1_Enable(bool b);
		void Interrupt_PWM0_Enable(bool b);
		uint8_t Interrupt_Status(void);
		void VSYNC_WaitReady(void);
		void Interrupt_ClearResume_Flag(void);
		void ExtInterrupt_ClearInput_Flag(void);
		void Interrupt_ClearI2CM_Flag(void);
		void Interrupt_ClearVSync_Flag(void);
		void Interrupt_ClearKeyScan_Flag(void);
		bool Interrupt_IsKeyPressed(void);
		void Interrupt_ClearMultiEventTask_Flag(void);
		void Interrupt_ClearPWM0_Flag(void);
		void Interrupt_ClearPWM1_Flag(void);
		
		void Enable_PIP1(bool b);
		void Enable_PIP2(bool b);
		void Select_PIP_Parameter(PIPSelect pip);
		void Select_MainWindow_8bpp(void);
		void Select_MainWindow_16bpp(void);
		void Select_MainWindow_24bpp(void);
		void Select_LCD_SyncMode(void);
		void Select_LCD_DEMode(void);
		
		void Mask_XnWAIT(bool mask);
		void TFT_24bit(void);
		void TFT_18bit(void);
		void TFT_16bit(void);
		void TFT_Without(void);
		void TFT_Interface(TFTInterface mode);
		
		void HostDataBus_Select_8bit(void);
		void HostDataBus_Select_16bit(void);
        void SFlashSPI_Enable(bool b);
		
        void HostColorDepthFormat(uint8_t type);
		void HostReadMemoryDirection(MemoryDirection direction);
		void HostWriteMemoryDirection(MemoryDirection direction);
		
		void HScanDirection_LeftToRight(void);
		void HScanDirection_RightToLeft(void);
		void HorizontalScanDirection(HSCANDir direction);
		void VScanDirection_TopToBottom(void);
		void VScanDirection_BottomToTop(void);
		void VerticalScanDirection(VSCANDir direction);
		void PDATA_ColorFmt(PDATAColorFmt fmt);
		void PCLK_Rising(void);
		void PCLK_Falling(void);
		void PCLK_EdgeType(PCLKEdge edge);

        void HSYNC_PolarityLow(void);
		void HSYNC_PolarityHigh(void);
		void HSYNC_Polarity(HSYNCPolarity val);
		void VSYNC_PolarityLow(void);
		void VSYNC_PolarityHigh(void);
		void VSYNC_Polarity(VSYNCPolarity val);
        void DE_PolarityLow(void);
        void DE_PolarityHigh(void);
        void DE_Polarity(DEPolarity val);
		
		void HorizontalWidth_VerticalHeight(uint16_t WX, uint16_t HY);
		void Horizontal_NonDisplay(uint16_t hbpd);
		void HSYNC_StartPosition(uint16_t hfpd);
		void HSYNC_PulseWidth(uint16_t hspw);
		void Vertical_NonDisplay(uint16_t vbpd);
		void VSYNC_StartPosition(uint16_t vfpd);
		void VSYNC_PulseWidth(uint8_t vspw);
		void LCD_SetPanel(void);
		
		void Memory_BlockMode(void);
		bool Memory_IsBlockMode(void);
		void Memory_XYMode(void);
		bool Memory_IsXYMode(void);
		void Memory_LinearMode(void);
		bool Memory_IsLinearMode(void);
		void Memory_8bpp_BlockMode(void);
		void Memory_16bpp_BlockMode(void);
		void Memory_24bpp_BlockMode(void);
		
		uint8_t SPIM_TxRxFIFOData_Get(void);
		uint8_t SPIM_TxRxFIFOData_Put(uint8_t data);
		bool SPIM_TxFIFO_Empty(void);
        bool SPIM_TxFIFO_Full(void);
		bool SPIM_RxFIFO_Empty(void);
		bool SPIM_RxFIFO_Full(void);
		bool Interrupt_Overflow_Flag(void);
		void Interrupt_ClearOverflow_Flag(void);
		bool EMTI_Flag(void);
		void EMTI_Clear_Flag(void);
		
		void SPI_Clock_Period(uint8_t divisor);
		
		void Interrupt_ActiveLevel(InterruptLevel level);
		void ExtInterrupt_Debounce(void);
		void ExtInterrupt_NoDebounce(void);
		void ExtInterrupt_InputLevelTrigger(eInterrupLevelTrigger leveltrg);
		void LVDS_DataFormat_VESA(void);
		void LVDS_DataFormat_JEIDA(void);
		
		void nSS_Select_Channel(eNSS_Channel channel);
		void Interrupt_SPIM_Enable(bool b);
		void nSS_Inactive(void);
		void nSS_Active(void);
		void Interrupt_FIFOOverflow_Enable(bool b);
		void Interrupt_EMTIRQEN_Enable(bool b);
		void Reset_CPOL(void);
		void Set_CPOL(void);
		void Reset_CPHA(void);
		void Set_CPHA(void);
		
		void DrawEnable_AA(bool b);             //Verificar se funcao do RA8876/RA8877
		void LineMode_Start(void);
        void TriangleMode_Start(bool fill);
        void CircleMode_Start(bool fill);
		void EllipseMode_Start(bool fill);
		void CurveLeftDownMode_Start(bool fill);
		void CurveLeftUpMode_Start(bool fill);
		void CurveRightUpMode_Start(bool fill);
		void CurveRightDownMode_Start(bool fill);
		void SquareMode_Start(bool fill);
		void CircleSquareMode_Start(bool fill);
		
         void Point1_XY(uint16_t wx, uint16_t hy);
		void Point2_XY(uint16_t wx, uint16_t hy);
		void Point3_XY(uint16_t wx, uint16_t hy);
		void Line_Point1XY(uint16_t wx, uint16_t hy);            //Mesmo que Point1_XY()
		void Line_Point2XY(uint16_t wx, uint16_t hy);            //Mesmo que Point2_XY()
		void Triangle_Point1XY(uint16_t wx, uint16_t hy);        //Mesmo que Point1_XY()
		void Triangle_Point2XY(uint16_t wx, uint16_t hy);        //Mesmo que Point2_XY()
		void Triangle_Point3XY(uint16_t wx, uint16_t hy);        //Mesmo que Point3_XY()
		void Square_Point1XY(uint16_t wx, uint16_t hy);          //Mesmo que Point1_XY()
		void Square_Point2XY(uint16_t wx, uint16_t hy);          //Mesmo que Point2_XY()
        void Radius_RxRy(uint16_t Rx, uint16_t Ry);
		void CircleRadius_R(uint16_t R);                         //Adaptado, mesmo que Radius_RxRy()
        void EllipseRadius_RxRy(uint16_t Rx, uint16_t Ry);       //Mesmo que Radius_RxRy()
        void CircleSquareRadius_RxRy(uint16_t Rx, uint16_t Ry);  //Mesmo que Radius_RxRy()
		void Center_XY(uint16_t Wx, uint16_t Hy);
		void CircleCenter_XY(uint16_t Wx, uint16_t Hy);          //Mesmo que Center_XY()
        void EllipseCenter_XY(uint16_t Wx, uint16_t Hy);         //Mesmo que Center_XY()

        void Font_UseUserDefined(void);
        void Font_UseInternalCGROM(void);
		void Font_UseExternalCGROM(void);
		void Font_SetSource(FontSource source);
        void Font_SetHeight_16(void);
		void Font_SetHeight_24(void);
		void Font_SetHeight_32(void);
		void Font_SetHeight(FontHeight height);
        void Select_Internal_CGROM_ISOIEC8859_1(void);
		void Select_Internal_CGROM_ISOIEC8859_2(void);
		void Select_Internal_CGROM_ISOIEC8859_4(void);
		void Select_Internal_CGROM_ISOIEC8859_5(void);
        void Select_Internal_CGROM_ISO8859(InternalCGROM_ISO8859 iso);
		void GTFont_Select_GT21L16T1W(void);
		void GTFont_Select_GT30L16U2W(void);
		void GTFont_Select_GT30L24T3Y(void);
		void GTFont_Select_GT30L24M1Z(void);
		void GTFont_Select_GT30L32S4W(void);
		void GTFont_Select_GT20L24F6Y(void);
		void GTFont_Select_GT21L24S1W(void);
		void GTFont_SetDecoder(uint8_t temp);
		void Font_LineDistance(uint8_t gap);
		void Font_toFontWidthSetting(uint8_t pixels);
		
		void Font_FullAlignmentEnable(void);
		void Font_FullAlignmentDisable(void);
        void Font_UseBackgroundTransparency(void);
        void Font_UseBackgroundColor(void);
        void Font_0degree(void);
		void Font_90degree(void);
		void Font_WidthEnlargFactor(FontEnlargFactor factor);
		void Font_HeightEnlargFactor(FontEnlargFactor factor);
		void CGRAM_StartAddress(uint32_t addr);
		
		void SFI_DMA_WaitReady(void);
		void SFI_DMA_Start(void);
		void Select_SFI_FontMode(void);
		void Select_SFI_DMAMode(void);
		void Select_SFI_24bitAddress(void);
		void Select_SFI_32bitAddress(void);
		
		void Select_SFI_SingleData_03h(void);
		void Select_SFI_SingleData_0Bh(void);
		void Select_SFI_SingleData_1Bh(void);
        void Select_SFI_DualData_3Bh(void);
		void Select_SFI_DualData_BBh(void);               //Only RA8876/RA8877
		void Select_SFI_QuadData_6Bh(void);
		void Select_SFI_QuadData_EBh(void);
		
		void SFI_Select_ROM0(void);
		void SFI_Select_ROM1(void);
		
		void IDEC_SPI_Select_StandardMode0orMode3(void);  //Only RA8876/RA8887
		void IDEC_RA8875_SPI_Select_Mode0andMode3(void);  //Only RA8876/RA8887
		void SFI_Select_WaveformMode0(void);              //Only RA8876/RA8887
		void SFI_Select_WaveformMode3(void);              //Only RA8876/RA8887
		
		void PWM_Prescaler(uint8_t prescaler);
        void PWM0_ClockDividedBy(eDividerClock divider);
		void PWM1_ClockDividedBy(eDividerClock divider);
		void PWM1_Select_ErrorFlag(void);
		void PWM1_Select(void);
		void PWM1_Select_OscillatorClock(void);
		void PWM0_Select_GPIOC7(void);
		void PWM0_Select(void);
		void PWM0_Select_CoreClock(void);
		void PWM1_InverterOn(boolean on);
		void PWM1_Select_AutoReload(void);
		void PWM1_Select_OneShot(void);
		void PWM1_StartTimer(void);
		void PWM1_StopTimer(void);
		void PWM0_DeadZoneEnable(bool b);
		void PWM0_InverterOn(bool on);
		void PWM0_Select_AutoReload(void);
		void PWM0_Select_OneShot(void);
		void PWM0_StartTimer(void);
		void PWM0_StopTimer(void);
        void PWM0_DeadZoneLength(uint8_t len);
		void PWM0_SetCompareBuffer(uint16_t Wx);
		void PWM0_SetCountBuffer(uint16_t Wx);
		void PWM1_SetCompareBuffer(uint16_t Wx);
		void PWM1_SetCountBuffer(uint16_t Wx);
		
		void SFI_DMA_SourceAddress(uint32_t addr);
		void SFI_DMA_DestinationAddress(uint32_t addr);
		void SFI_DMA_DestinationUpperLeftCorner(uint16_t Wx, uint16_t Hy);
		void SFI_DMA_TransferNumber(uint32_t addr);
		void SFI_DMA_TransferWidthHeight(uint16_t Wx, uint16_t Hy);
		void SFI_DMA_SourceWidth(uint16_t Wx);
				
		void Power_NormalMode(void);
		void Power_SavingStandbyMode(void);
		void Power_SavingSuspendMode(void);
		void Power_SavingSleepMode(void);
		void I2CM_ClockPrescale(uint16_t prescale);
		void I2CM_TransmitData(uint8_t data);
		uint8_t I2CM_Receiver_Data(void);
		void I2CM_SetFrequency(uint32_t xscl_hz);
		
		void BTE_WaitReady(void);
		void BTE_DualWaitReady(void);
		void BTE_PatternFormat8X8(void);
		void BTE_PatternFormat16X16(void);
		void BTE_Enable(bool b);
		void BTE_OperationCode(eBTEOpCode opcode);
		void BTE_S0_ColorDeph(eColorDepthBPP bpp);

        void BTE_S1_ColorDeph_8bpp(void);
        void BTE_S1_ColorDeph_16bpp(void);
        void BTE_S1_ColorDeph_24bpp(void);
        void BTE_S1_ColorDeph_Constant(void);
        void BTE_S1_ColorDeph_8bitAlpha(void);
        void BTE_S1_ColorDeph_16bitAlpha(void);
        void BTE_Destination_ColorDeph(eColorDepthBPP bpp);
		void BTE_S0_MemoryStartAddress(uint32_t addr);
		void BTE_S0_ImageWidth(uint16_t Wx);
		void BTE_S0_WindowStart_XY(uint16_t Wx, uint16_t Hy);
		void BTE_S1_MemoryStartAddress(uint32_t addr);
		void S1_ConstantColor_256(uint8_t color);
		void S1_ConstantColor_65k(uint16_t color);
		void S1_ConstantColor_16M(uint32_t color);
		void BTE_S1_ImageWidth(uint16_t Wx);
		void BTE_S1_WindowStart_XY(uint16_t Wx, uint16_t Hy);
		void BTE_Destination_MemoryStartAddress(uint32_t addr);
		void BTE_Destination_ImageWidth(uint16_t Wx);
		void BTE_Destination_WindowStart_XY(uint16_t Wx, uint16_t Hy);
		void BTE_WindowSize(uint16_t Wx, uint16_t Hy);
		void BTE_AlphaBlendingEffect(uint8_t value);
		void BTE_ROPCode(eROPCode code);
		
		void PIP1_Window_ColorDepth(eColorDepthBPP bpp);
		void PIP2_Window_ColorDepth(eColorDepthBPP bpp);

	private:

	protected:
		uint8_t _cs;	            //chip select pin
		uint8_t _rst;	            //chip reset pin
		uint16_t _width;            //lardura do display
		uint16_t _height;           //altura do display
		eColorDepthBPP _bpp;        //color depht 8/16/24 bit per pixel (bpp)
		uint8_t _colorfmt;          //formato da cor RGB, RBG, GRB, GBR, ....
		uint32_t _spi_clockmax;     //velocidade de comunucacao de clock maximo do SPI
		uint8_t _spi_datamode;      //SPI_MODE0[1,2,3] de comunicacao
		uint8_t _spi_dataorder;     //ordem de dados spi MSBFIRST ou LSBFIRST

};
